# Genstat2020
Planning and materials for NORBIS course GENSTAT (2020)

The official page: https://folk.uib.no/gjessing/genetics/software/haplin/other/NORBIS_2020/intro/
