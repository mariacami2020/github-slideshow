# Genstat2020
Planning and materials for NORBIS course GENSTAT (2020)

The official page: https://folk.uib.no/gjessing/genetics/software/haplin/other/NORBIS_2020/intro/

## Presentations in html

### DAY 5

[Gene-methylation interactions](DAY5/JRom_GxMe/gene-methyl_interact_JRomanowska.html)

[Bioinformatics databases and services](DAY5/JRom_bioinf_DB/JRom_bioinf_DBs.html)
